﻿using System;

namespace BirdWatcher.Web.Models
{
    public class Observation
    {
        public int Id { get; set; }
        public string  Specie { get; set; }
    }
}
