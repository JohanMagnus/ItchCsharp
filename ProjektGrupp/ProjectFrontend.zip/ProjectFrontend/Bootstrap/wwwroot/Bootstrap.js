﻿let home = document.getElementById("home")

home.addEventListener("click", () => {

	document.location.href = 'https://localhost:44333/Main.html'


});

let shop = document.getElementById("shop")

shop.addEventListener("click", () => {

document.location.href = 'https://localhost:44333/shop.html'


});

let contact = document.getElementById("contact")

contact.addEventListener("click", () => {


	document.location.href = 'https://localhost:44333/Contact.html'


});

let buttonContact = document.getElementById("buttonContact")
buttonContact.addEventListener("click", () => {
    alert("073 70 50 666");
})
